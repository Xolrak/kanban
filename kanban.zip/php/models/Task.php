<?php
class Task {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getAll() {
        $stmt = $this->pdo->query('SELECT * FROM tasks ORDER BY created_at DESC');
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM tasks WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create($description, $status, $priority) {
        $stmt = $this->pdo->prepare("INSERT INTO tasks (description, status, priority) 
                                     VALUES (:description, :status, :priority)");
        $stmt->execute([
            ':description' => $description,
            ':status' => $status,
            ':priority' => $priority
        ]);
        return $this->pdo->lastInsertId();
    }

    public function update($id, $fields) {
        $setParts = [];
        $params = [':id' => $id];
        
        foreach ($fields as $key => $value) {
            $setParts[] = "$key = :$key";
            $params[":$key"] = $value;
        }
        
        $sql = "UPDATE tasks SET " . implode(', ', $setParts) . " WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($params);
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare("DELETE FROM tasks WHERE id = ?");
        return $stmt->execute([$id]);
    }
}