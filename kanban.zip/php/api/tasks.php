<?php
// Headers CORS - IMPORTANTE: deben ir al inicio
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Manejar peticiones OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

// ✅ CORREGIDO: Ahora apunta al controlador en la nueva estructura
require_once __DIR__ . '/../controllers/TaskController.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = $_GET['id'] ?? null;

try {
    $controller = new TaskController($pdo);
    
    switch ($method) {
        // 1️⃣ GET - Obtener todas las tareas
        case 'GET':
            $tasks = $controller->getAllTasks();
            echo json_encode($tasks);
            break;

        // 2️⃣ POST - Crear nueva tarea
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            $task = $controller->createTask($data);
            http_response_code(201);
            echo json_encode($task);
            break;

        // 3️⃣ PUT - Actualizar tarea completa
        case 'PUT':
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID de tarea requerido']);
                exit;
            }
            $data = json_decode(file_get_contents('php://input'), true);
            $task = $controller->updateTask($id, $data);
            echo json_encode($task);
            break;

        // 4️⃣ PATCH - Actualizar campos específicos
        case 'PATCH':
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID de tarea requerido']);
                exit;
            }
            $data = json_decode(file_get_contents('php://input'), true);
            $task = $controller->updateTask($id, $data);
            echo json_encode($task);
            break;

        // 5️⃣ DELETE - Eliminar tarea
        case 'DELETE':
            if (!$id) {
                http_response_code(400);
                echo json_encode(['error' => 'ID de tarea requerido']);
                exit;
            }
            $task = $controller->deleteTask($id);
            echo json_encode([
                'message' => 'Tarea eliminada correctamente',
                'deleted_task' => $task
            ]);
            break;

        // Método no permitido
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido']);
            break;
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}