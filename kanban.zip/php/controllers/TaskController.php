<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Task.php';

class TaskController {
    private $taskModel;

    public function __construct($pdo) {
        $this->taskModel = new Task($pdo);
    }

    public function getAllTasks() {
        return $this->taskModel->getAll();
    }

    public function createTask($data) {
        if (!isset($data['description']) || empty(trim($data['description']))) {
            throw new Exception('La descripción es obligatoria');
        }
        
        $status = $data['status'] ?? 'Some day';
        $priority = $data['priority'] ?? 'medium';
        
        $id = $this->taskModel->create($data['description'], $status, $priority);
        return $this->taskModel->getById($id);
    }

    public function updateTask($id, $data) {
        $task = $this->taskModel->getById($id);
        if (!$task) {
            throw new Exception('Tarea no encontrada');
        }
        
        $fieldsToUpdate = [];
        if (isset($data['description'])) {
            $fieldsToUpdate['description'] = $data['description'];
        }
        if (isset($data['status'])) {
            $fieldsToUpdate['status'] = $data['status'];
        }
        if (isset($data['priority'])) {
            $fieldsToUpdate['priority'] = $data['priority'];
        }
        
        if (empty($fieldsToUpdate)) {
            throw new Exception('No hay campos para actualizar');
        }
        
        $this->taskModel->update($id, $fieldsToUpdate);
        return $this->taskModel->getById($id);
    }

    public function deleteTask($id) {
        $task = $this->taskModel->getById($id);
        if (!$task) {
            throw new Exception('Tarea no encontrada');
        }
        
        $this->taskModel->delete($id);
        return $task;
    }
}