import { TaskManager } from './kanban.js';

document.addEventListener('DOMContentLoaded', () => {
    const taskManager = new TaskManager();
});