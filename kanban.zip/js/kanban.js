import { TaskAPI } from './api.js';

class TaskManager {
    constructor() {
        this.tasks = [];
        this.editingId = null;
        this.init();
    }

    async init() {
        await this.loadTasks();
        this.render();
    }

    async loadTasks() {
        try {
            this.tasks = await TaskAPI.getTasks();
            document.getElementById('loading').style.display = 'none';
            document.getElementById('taskTable').style.display = 'table';
            this.hideError();
        } catch (error) {
            this.showError('Error al cargar las tareas: ' + error.message);
        }
    }

    showError(message) {
        const errorDiv = document.getElementById('error');
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        document.getElementById('loading').style.display = 'none';
    }

    hideError() {
        document.getElementById('error').style.display = 'none';
    }

    autoResize(textarea) {
        textarea.style.height = 'auto';
        textarea.style.height = textarea.scrollHeight + 'px';
    }

    getStatusBadge(status) {
        const statusClass = status.toLowerCase().replace(' ', '');
        return `<span class="status-badge status-${statusClass}">${status}</span>`;
    }

    getPriorityBadge(priority) {
        return `<span class="priority-badge priority-${priority}">${priority}</span>`;
    }

    createEditRow(task = null) {
        const isNew = !task;
        const tr = document.createElement('tr');
        if (isNew) tr.className = 'new-row';

        tr.innerHTML = `
            <td>
                <textarea placeholder="Escribe la descripción de la tarea...">${task ? task.description : ''}</textarea>
            </td>
            <td>
                <select>
                    <option value="Some day" ${task?.status === 'Some day' ? 'selected' : ''}>Some day</option>
                    <option value="To do" ${task?.status === 'To do' ? 'selected' : ''}>To do</option>
                    <option value="In progress" ${task?.status === 'In progress' ? 'selected' : ''}>In progress</option>
                    <option value="Done" ${task?.status === 'Done' ? 'selected' : ''}>Done</option>
                    <option value="Today" ${task?.status === 'Today' ? 'selected' : ''}>Today</option>
                    <option value="Tomorrow" ${task?.status === 'Tomorrow' ? 'selected' : ''}>Tomorrow</option>
                    <option value="Deleted" ${task?.status === 'Deleted' ? 'selected' : ''}>Deleted</option>
                    <option value="This week" ${task?.status === 'This week' ? 'selected' : ''}>This week</option>
                </select>
            </td>
            <td>
                <select>
                    <option value="low" ${task?.priority === 'low' ? 'selected' : ''}>Low</option>
                    <option value="medium" ${task?.priority === 'medium' ? 'selected' : ''}>Medium</option>
                    <option value="high" ${task?.priority === 'high' ? 'selected' : ''}>High</option>
                    <option value="top" ${task?.priority === 'top' ? 'selected' : ''}>Top</option>
                </select>
            </td>
            <td>
                <div class="actions">
                    <button class="btn-save">${isNew ? '➕ Crear' : '💾 Guardar'}</button>
                    ${!isNew ? '<button class="btn-cancel">❌ Cancelar</button>' : ''}
                </div>
            </td>
        `;

        const textarea = tr.querySelector('textarea');
        textarea.addEventListener('input', () => this.autoResize(textarea));
        this.autoResize(textarea);

        const saveBtn = tr.querySelector('.btn-save');
        saveBtn.addEventListener('click', () => {
            const description = textarea.value.trim();
            const status = tr.querySelectorAll('select')[0].value;
            const priority = tr.querySelectorAll('select')[1].value;

            if (isNew) {
                this.createTask(description, status, priority);
            } else {
                this.updateTask(task.id, description, status, priority);
            }
        });

        if (!isNew) {
            const cancelBtn = tr.querySelector('.btn-cancel');
            cancelBtn.addEventListener('click', () => {
                this.editingId = null;
                this.render();
            });
        }

        return tr;
    }

    createViewRow(task) {
        const tr = document.createElement('tr');
        tr.dataset.id = task.id;

        tr.innerHTML = `
            <td>
                <div class="view-mode">${task.description}</div>
            </td>
            <td>
                <div class="view-mode">${this.getStatusBadge(task.status)}</div>
            </td>
            <td>
                <div class="view-mode">${this.getPriorityBadge(task.priority)}</div>
            </td>
            <td>
                <div class="actions">
                    <button class="btn-delete">🗑️ Eliminar</button>
                </div>
            </td>
        `;

        const viewCells = tr.querySelectorAll('.view-mode');
        viewCells.forEach(cell => {
            cell.addEventListener('dblclick', () => {
                this.editingId = task.id;
                this.render();
            });
        });

        const deleteBtn = tr.querySelector('.btn-delete');
        deleteBtn.addEventListener('click', () => this.deleteTask(task.id));

        return tr;
    }

    render() {
        const tbody = document.getElementById('taskBody');
        tbody.innerHTML = '';

        this.tasks.forEach(task => {
            if (task.id === this.editingId) {
                tbody.appendChild(this.createEditRow(task));
            } else {
                tbody.appendChild(this.createViewRow(task));
            }
        });

        tbody.appendChild(this.createEditRow());
    }

    async createTask(description, status, priority) {
        if (!description) {
            alert('La descripción es obligatoria');
            return;
        }

        try {
            await TaskAPI.createTask(description, status, priority);
            await this.loadTasks();
            this.render();
        } catch (error) {
            alert('Error al crear la tarea: ' + error.message);
        }
    }

    async updateTask(id, description, status, priority) {
        if (!description) {
            alert('La descripción es obligatoria');
            return;
        }

        try {
            await TaskAPI.updateTask(id, description, status, priority);
            await this.loadTasks();
            this.editingId = null;
            this.render();
        } catch (error) {
            alert('Error al actualizar la tarea: ' + error.message);
        }
    }

    async deleteTask(id) {
        if (!confirm('¿Estás seguro de eliminar esta tarea?')) {
            return;
        }

        try {
            await TaskAPI.deleteTask(id);
            await this.loadTasks();
            this.render();
        } catch (error) {
            alert('Error al eliminar la tarea: ' + error.message);
        }
    }
}

export { TaskManager };