# 📋 Kanban Board - Sistema de Gestión de Tareas

Aplicación web completa para gestión de tareas tipo Kanban con arquitectura MVC.

## 🚀 Características

- ✅ CRUD completo de tareas (Crear, Leer, Actualizar, Eliminar)
- ✅ API RESTful con PHP
- ✅ Interfaz responsive y moderna
- ✅ Arquitectura MVC (Modelo-Vista-Controlador)
- ✅ Base de datos MySQL
- ✅ Validación de datos en frontend y backend

## 📦 Instalación

### Requisitos previos
- XAMPP (Apache + MySQL + PHP 7.4+)
- Navegador web moderno

### Pasos de instalación

1. **Clonar/copiar el proyecto** en la carpeta `htdocs` de XAMPP: